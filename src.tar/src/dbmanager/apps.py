from django.apps import AppConfig


class DbmanagerConfig(AppConfig):
    name = 'dbmanager'
