from django.apps import AppConfig


class InviteConfig(AppConfig):
    name = 'invite'
